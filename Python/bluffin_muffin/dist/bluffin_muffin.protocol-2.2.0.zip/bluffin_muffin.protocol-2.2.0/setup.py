from setuptools import setup, find_packages

setup(
    name='bluffin_muffin.protocol',
    version='2.2.0',
    packages=find_packages(),
    url='',
    license='',
    author='ericmas001',
    author_email='',
    description=''
)
